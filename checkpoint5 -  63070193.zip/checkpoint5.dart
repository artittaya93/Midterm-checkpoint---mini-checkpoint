void main() {
  String studentName = "Alexander Mohamad";
  List<int> scores = [8,30,17,18];
  int totalscores = 0;
  for (int i in scores){
    totalscores += i;
  }
  print(totalscores);
  

// TODO : Add your code here
}
