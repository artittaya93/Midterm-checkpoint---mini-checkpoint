import "dart:io";
void main(){
  print("1.What is your name?");
  String? name = stdin.readLineSync();
  print("2.How many score does he/she have?");
  String? name1 = stdin.readLineSync();
print("$name has a $name1 ");
  
  
}
  