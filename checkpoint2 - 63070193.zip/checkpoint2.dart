void main(){
   String studentName = "Alexander Mohamad";
   int a = 8;
   int b = 30;
   int c = 17;
   int d = 18;
   int e = a + b + c + d; //equal 73
   print(studentName + "'s total score is " + e.toString() );

}